package cz.kobrinf.mygratulok

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toolbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //val toolbark = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar1)
        //setSupportActionBar(toolbark)

        val button = findViewById<Button>(R.id.button1)

        button.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

    }



}